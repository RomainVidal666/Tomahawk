var searchData=
[
  ['name',['name',['../struct_h_t_t_p___node.html#a5ac083a645d964373f022d03df4849c8',1,'HTTP_Node']]],
  ['nb_5fchilds',['nb_childs',['../struct_h_t_t_p___node.html#a7ef173e87af6384077b245308271482d',1,'HTTP_Node']]]
];
